Demo code for CVPR submission #7690:
"Diffeomorphic Template Registration for Atmospheric Turbulence Mitigation."

Please run "demo.m"